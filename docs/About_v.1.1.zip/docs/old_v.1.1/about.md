# NoobScience

Hello World! I am NoobScience, I love working with and learning python. I am currently learning rust and a little Web development.\

I love making small projects and hosting them on github.

I am a huge believer in the [open source](https://opensource.org/about) mission and I love making open source alternatives to some major close sourced projects and I some times try to contribute to some projects.

I also like writing small websites like this. I am a huge fan of customization. I gues you can say so by just looking at my desktop.

![desktop image](assets/desktop.png)

Yes I use Windows even though I believe in open source. Don't judge me.

I made a custom Rainmeter skin I use regularly. I didn't release it yet, but I think it is pretty cool. You can very soon find it on my [github](https://github.com/newtoallofthis123). 

I guess one of the most interesting projects of mine is [NoobNote](https://newtoallofthis123.github.io/NoobNote). It is a very nice alternative to Notepad. Notepad is very nostalgic for many and NoobNote is a attempt to have that nostalgia without using closed source Microsoft Products. NoobNote has many branches like LiteNote, NoobNote_dev and recently coming CompactNote. 

![NoobNote Image](assets/NoobNote.png)

# Contact

You can contact me at my public github email or my personal email address at [noobscience123@gmail.com](mailto:noobscience123@gmail.com).

# License

All my projects being open source are license under the [MIT LICENSE](https://newtoallofthis123.github.io/license)

You are free to use them as you like, but try to credit me if you can.

# Contribute

The while point of open source is for you to be able to contribute as well.

If you like what I do and like to support me, you can leave a star at my [github](https://github.com/newtoallofthis123) page or subscribe to my [youtube](https://www.youtube.com/channel/UCbYWy7rhUhToM3tbw-Z3SnQ) channel.

# Thanks You For Reading This...

You can find more about me on my [website](https://newtoallofthis123.github.io/About).

> NoobScience
